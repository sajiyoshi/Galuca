This folder MUST have 3 files ("beePaths.txt","butterFlyPaths.txt","galagaBossPaths.txt")
If it does not have these files, the game will not be playable. 

Default settings are: (\n just means new line)

"beePaths"
1 (\n)
2 

"butterflyPaths"
1

"galagaBossPaths"
1 (\n)
2 

If you would like to delete a path from an enemy's attack, 
simply delete the FULL line of points from their file.
Otherwise... DON'T TOUCH PLEASE! :)