import sys,pygame
from pygame.locals import *
pygame.init()

import random
import fractions
import math

class Galaga(object):
    screenScale = 2.5 #Changes the game Window Size
    def __init__(self):
        self.baseWidth = 224
        self.baseHeight = 288
        self.baseHeader = 30
        self.baseFoot = 30
        self.header = self.baseHeader * self.screenScale
        self.screenWidth = int(self.baseWidth * self.screenScale)
        self.screenHeight = int((self.baseHeight + self.baseHeader)\
                                * self.screenScale)
        self.runGalaga()
        
    def runGalaga(self):
        self.init()
        while True:
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == KEYDOWN or event.type == KEYUP:
                    self.keyPressed(event)
            self.keepTime()
            if not self.gameOver:
                self.moveGalaga()
                self.drawGalaga()
            else:
                self.gameOverMsg()
            pygame.time.delay(int(1000/self.fps)) #1000 milliseconds/fps

    def keepTime(self):
        self.milliseconds += self.clock.tick()
        self.seconds = self.milliseconds/1000.0
        
    def init(self):
        self.gameTitle = "Galuca"
        self.fps = 60.0
        self.gameOver = False
        self.initScreen()
        self.initObjects()
        self.initFighter()
        self.initEnemies()
        
    def keyPressed(self,event):
        if event.type == KEYDOWN:
            if event.key == K_LEFT:
                self.fighter.vx = -self.fighter.speed
            elif event.key == K_RIGHT:
                self.fighter.vx = self.fighter.speed
            elif event.key == K_SPACE:
                if len(self.missileList) < Missile.maxMissiles:
                    self.shotsFired += 1
                    self.missileList.append(self.fighter.fireMissile(self.\
                                                        fighterMissileSpeed))
        elif event.type == KEYUP:
            if event.key == K_LEFT:
                if self.fighter.vx < 0:
                    self.fighter.vx = 0
            elif event.key == K_RIGHT:
                if self.fighter.vx >0:
                    self.fighter.vx = 0

    def initEnemies(self):
        totalEnemies = self.formation.totalEnemies
        bossGalaga = self.formation.bossGalaga
        butterflies = self.formation.butterflies
        bees = self.formation.bees
        for enemy in xrange(self.formation.totalEnemies):
            position = self.formation.positionList[enemy]
            if enemy < bossGalaga:
                self.enemyList.append(EnemyGalaga(position[0],position[1]))
            elif enemy < bossGalaga + butterflies:
                self.enemyList.append(EnemyButterfly(position[0],position[1]))
            else:
                self.enemyList.append(EnemyBee(position[0],position[1]))
                
        for enemy in self.enemyList:
            (enemy.floatVX,enemy.floatVY) = Movement.calculateFloat(enemy,self)
                
    def initFighter(self):
        self.fighterMissileSpeed = -int(self.screenHeight/self.fps*1.5)
        self.fighter = Fighter(self)
        
    def initObjects(self):
        #Speed Objects
        self.PPS = 100 * Galaga.screenScale #Pixels per second
        self.PPT = self.PPS / self.fps #Pixels per Tick

        #Missile Objects
        self.missileList = []

        #Star Objects / Animation Parameters
        self.starList = []
        baseStarSize = 1
        self.starSizes = [baseStarSize,baseStarSize*2,baseStarSize*3-1]
        baseStarSpeed = self.screenHeight/200
        self.starSpeeds = [-baseStarSpeed,-int(baseStarSpeed*1.3),
                           -int(baseStarSpeed*1.6)]

        #Enemy Objects
        self.enemyList = []

        #Formation Objects
        self.formation = Formations(1,self) #Basic Formation

        #Explosion animation Objects
        self.explosionList = []

        #Score Objects
        self.score = 0

        #Shot Objects
        self.shotsFired = 0
        self.shotsHit = 0

        #Time Objects
        self.clock = pygame.time.Clock() #Initialize game clock
        self.milliseconds = 0

        #Font Objects
        self.gameFont = pygame.font.SysFont("Arial",30)

        #Gameplay objects
        self.score = 0
        self.lives = 3

        #Level Objects
        self.level = 1
        self.levelChecker = 0
        self.maxLevelSeconds = 3
        
    def initScreen(self):
        self.screenSize = self.screenWidth,self.screenHeight
        self.screen = pygame.display.set_mode(self.screenSize)
        pygame.display.set_caption(self.gameTitle)
        
    def drawGalaga(self):
        self.drawScreen()
        pygame.display.update()

    def drawScreen(self):
        self.screen.fill((0,0,0))# Black Backdrop
        self.drawStars()
        self.drawFighter()
        self.drawEnemies()
        self.drawMissiles()
        self.drawExplosions()
        self.drawHeader()

    def drawHeader(self):
        pygame.draw.rect(self.screen,(0,0,0),((0,0),(self.screenWidth,self.header)))
        oneUp = self.gameFont.render("1UP",1,(255,0,0),(0,0,0))
        highScore = self.gameFont.render("High Score",1,(255,0,0),(0,0,0))
        level = "Level %s" % self.level
        levelText = self.gameFont.render(level, 1, (0,0,255),(0,0,0))
        self.screen.blit(oneUp,(self.screenWidth/5,0))
        self.screen.blit(levelText, (self.screenWidth/2 - 30,self.header))
        self.screen.blit(highScore,(self.screenWidth/2 - self.screenWidth/10 ,0))
        self.drawLives()
        self.drawScore()

    def drawLives(self):
        xPosition = self.screenWidth - self.fighter.width * 2
        for life in xrange(self.lives):
            self.screen.blit(self.fighter.image,(xPosition,0))
            xPosition -= self.fighter.width + self.fighter.width/2

    def drawScore(self):
        score = str(self.score)
        score = self.gameFont.render(score,1,(255,255,255),(0,0,0))
        self.screen.blit(score,(self.screenWidth/5,50))
              
    def drawEnemies(self):
        for enemy in self.enemyList:
            enemy.draw(self)

    def drawMissiles(self):
        for missile in self.missileList:
            missile.draw(self)

    def drawStars(self):
        starLife = self.fps/2
        starWait = self.fps/10
        for star in self.starList:
            if star.flash == starLife: #Reset Star Flash
                star.flash = 0
            elif star.flash > starWait: #Only draw if flash is on.  
                star.draw(self) #Draw method
                star.flash += 1
            else:
                star.flash += 1
            
    def drawFighter(self):
        self.fighter.draw(self)

    def drawExplosions(self):
        for explosion in self.explosionList:
            explosion.draw(self)

    def moveGalaga(self):
        self.moveFighter()
        self.moveStars()
        self.moveMissiles()
        self.updateEnemies()
        self.moveEnemies()
        self.updateExplosions()
        self.checkForCollisions()

    def moveEnemies(self):
        for enemy in self.enemyList:
            enemy.move()

    def updateEnemies(self):
        Enemy.flutterCheck(self)
        Enemy.floatCheck(self)
        Enemy.attackingEnemies = 0
        for enemy in self.enemyList:
            if enemy.isAttacking:
                Enemy.attackingEnemies += 1
            enemy.update(self)
        if Enemy.attackingEnemies < Enemy.maxAttackingEnemies:
            enemy = random.choice(self.enemyList)
            if enemy.isAttacking == False:
                enemy.attack(self)
            sound = pygame.mixer.Sound('galaga_sounds/enemy/flying.wav')
            sound.play()
        self.enemyList = [enemy for enemy in self.enemyList \
                            if (enemy.isAlive)]

    def moveFighter(self):
        """Checks to ensure fighter is within the bounds of the board, and then
            moves the fighter in the proper direction."""
        if self.fighter.vx < 0:
            if self.fighter.x >= 0:
                self.fighter.x += self.fighter.vx
        elif self.fighter.vx > 0:
            if self.fighter.x <= self.screenWidth - self.fighter.width:
                self.fighter.x += self.fighter.vx

    def moveStars(self):
        numberOfStars = self.screenHeight/20
        startingStars = numberOfStars-1
        if len(self.starList) < startingStars:
               self.starList.append(Star.createStar(self,True))#Random star
        elif len(self.starList) < numberOfStars:
            self.starList.append(Star.createStar(self,False))#Non random star
        for star in self.starList:
            star.move()
        self.starList =[star for star in self.starList if star.isOnScreen(self)]

    def moveMissiles(self):
        for missile in self.missileList:
            missile.move()
        #Next Lines: Removes all missiles which have traveled off screen.
        self.missileList = [missile for missile in self.missileList \
                            if (missile.isOnScreen(self) and missile.isAlive)]
    def updateExplosions(self):
        for explosion in self.explosionList:
            explosion.update()
        self.explosionList = [explosion for explosion in self.explosionList \
                              if (explosion.isAlive)]

    def checkForCollisions(self):
        for enemy in self.enemyList:
            for missile in self.missileList:
                if (enemy.collisionWith(missile) and (missile.isAlive)):
                    self.shotsHit += 1
                    missile.isAlive = False
                    enemy.hitPoints -= 1  
                    if enemy.hitPoints == 0:
                        enemy.deathSound.play()
                        enemy.isAlive = False
                        self.score += enemy.points
                        self.explosionList.append(Explosion(enemy,self))
                        if len(self.enemyList) == 1:
                            print "Here!"
                            self.advanceLevel()
                    elif isinstance(enemy,EnemyGalaga):
                        enemy.weakSound.play()
                        enemy.openImage = enemy.weakOpenImage
                        enemy.closedImage = enemy.weakClosedImage
                    
            if (self.fighter.collisionWith(enemy) and (enemy.isAlive)):
                enemy.isAlive = False
                self.score += enemy.points
                self.explosionList.append(Explosion(self.fighter,self))
                self.lives -= 1
                self.fighter.deathSound.play()
                self.checkGameOver()

    def advanceLevel(self):
        self.level += 1
        Enemy.speedValue += .1
        if self.level % 2 == 0:
            Enemy.maxAttackingEnemies += 1
        self.initEnemies()

    def checkGameOver(self):
        if self.lives == 0:
            self.gameOver = True

    def gameOverMsg(self):
        endText = self.gameFont.render("Game Over!",1,(255,0,0),(0,0,0))
        self.screen.blit(endText,(self.screenWidth/2 - 100,self.screenHeight/2 + self.header/2))
        pygame.display.update()

###################
#Utility Functions#
###################
                    
def importImage(filePath,alpha,screenScale=Galaga.screenScale):
        """Imports an image and rescales it by the proper offset."""
        image = pygame.image.load(filePath)
        
        if alpha == True:
            image = image.convert_alpha()
        else:
            image = image.convert()
        imageHeight = int(image.get_height() * screenScale)
        imageWidth = int(image.get_width() * screenScale)
        
        return (pygame.transform.scale(image,(imageWidth,imageHeight)),
                                             imageHeight,imageWidth)

def almostEqual(val1,val2,delta):
    if abs(val1-val2) <= delta:
        return True
    else:
        return False

################################
#       Physics Objects        #
#Anything that moves on screen!#
################################

class PhysObj(object):
    def __init__(self,x,y,vx,vy):
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.isAlive = True

    def move(self):
        """Repositions a physics object by it's x and y velocity."""
        self.x += self.vx
        self.y += self.vy

    def isOnScreen(self,galaga):
        """Returns True if object is on screen and False otherwise."""
        if self.x < 0 or self.x > galaga.screenWidth or\
           self.y < 0 or self.y > galaga.screenHeight:
            return False
        else:
            return True

    def draw(self,galaga):
        galaga.screen.blit(self.image,(int(round(self.x)),int(round(self.y))))

    def importSprite(self,imageFilePath,alpha):
        (self.image,self.height,self.width) = \
              importImage(imageFilePath,True) #True == Alpha

    #Rotation function taken from: http://www.pygame.org/wiki/RotateCenter
    def rotateSprite(self,angle):
        """rotate an image while keeping its center and size"""
        orig_rect = self.image.get_rect()
        rot_image = pygame.transform.rotate(self.image, angle)
        rot_rect = orig_rect.copy()
        rot_rect.center = rot_image.get_rect().center
        rot_image = rot_image.subsurface(rot_rect).copy()
        self.image = rot_image #My Modification 
        
    def collisionWith(self,other,point = False):
        if point == False: #Colliding with an object
            hitBoxX0 = self.x-other.width
            hitBoxY0 = self.y
            hitBoxX1 = self.x+self.width+other.width
            hitBoxY1 = self.y+self.height
            if (other.x >= hitBoxX0 and other.x <= hitBoxX1) and \
               (other.y >= hitBoxY0 and other.y <= hitBoxY1):
                return True
            else:
                return False
        else: #Colliding with a point.
            #Uses Radial hit detection
            pointX = other[0]
            pointY = other[1]
            
            offset = self.width/10 
            
            centerX = self.x + self.width/2 
            centerY = self.y + self.height/2
            
            distance = ((centerX - pointX)**2 + (centerY -pointY)**2)**.5
            radius = offset
            if distance <= radius:
                return True
            else:
                return False
            

    @classmethod
    def getExplosions(self,classPath):
        imageList = []
        index = 1
        pathFound = True
        while pathFound:
            pathName = "galaga_sprites/explosions/%s_%d.png" % (classPath,index)
            try:
               imageList.append(importImage(pathName,True,Galaga.screenScale+1))
               index += 1
            except:
               pathFound = False
               return imageList
###########                
#Missiles!#
###########
            
class Missile(PhysObj):
    maxMissiles = 2 #Classic Galaga only allowed 4 missiles on screen. 
    def __init__(self,x,y,vx,vy,shooter):
        self.shooter = shooter
        self.importSprite()
        super(Missile,self).__init__(x-self.width/2,y-self.height,vx,vy)

    def importSprite(self):
        if self.shooter == "fighter":
            imageFilePath = "galaga_sprites/missiles/fighter_missile.png"
        elif self.shooter == "enemy":
            imageFilePath = "galaga_sprites/missiles/enemy_missile.png"
        super(Missile,self).importSprite(imageFilePath,True)

#########
#Fighter#
#########
        
class Fighter(PhysObj):
    def __init__(self,galaga):
        self.importSprite()
        self.setInitialLocation(galaga)
        self.speed = int(galaga.screenWidth/(galaga.fps)/3)
        self.deathSound = \
        pygame.mixer.Sound('galaga_sounds/fighter/death.wav')
        explosionPath = "fighter/explosion"
        self.expImages = PhysObj.getExplosions(explosionPath)
        super(Fighter,self).__init__(self.x,self.y,self.vx,self.vy)

    def importSprite(self):
        imageFilePath = "galaga_sprites/fighter/fighter.png"
        super(Fighter,self).importSprite(imageFilePath,True)
        
    def setInitialLocation(self,galaga):
        self.x = galaga.screenWidth/2 - self.width/2
        self.y = galaga.screenHeight - self.height
        #Next Lines: Inital Speed of fighter is 0. 
        self.vx = 0
        self.vy = 0

    def fireMissile(self,missileSpeed):
        #Set base parameters
        vx = 0
        vy = missileSpeed 
        shooter = "fighter"

        #Play missile Sound
        sound = pygame.mixer.Sound('galaga_sounds/fighter/fighter_shot1.wav')
        sound.play()

        #Return Missile Instance
        return Missile(self.x+self.width/2,self.y,vx,vy,shooter)

########
#Stars!#
########
    
class Star(PhysObj):
    def __init__(self,x,y,vx,vy,size,flash):
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.size = size
        self.flash = flash

    @classmethod
    def createStar(self,galaga,randomStar):
        """Choose random variables to create a circle which simulates stars
            with a paralax effect."""
        x = random.randint(0,galaga.screenWidth)
        if randomStar == False:
            y = 0
        else:
            y = random.randint(0,galaga.screenHeight)
        vx = 0
        vy = -random.choice(galaga.starSpeeds) 
        size = random.choice(galaga.starSizes) 
        flash = random.randint(0,galaga.fps/2)
        return Star(x,y,vx,vy,size,flash)

    def draw(self,galaga):
        pygame.draw.circle(galaga.screen,(255,255,255),(self.x,self.y),
                                                             self.size)
##########
#Enemies!#
##########
        
class Enemy(PhysObj):
    flutterImage = True
    flutterCount = 0
    floatOn = True
    floatCount = 0
    maxAttackingEnemies = 1
    attackingEnemies = 0
    speedValue = 1 # Higher Values == Faster Movement
    
    def __init__(self,x,y,vx,vy):
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.path = []
        self.isAlive = True
        self.isFlying = False
        self.isAttacking = False
        self.floatX = self.homeX - self.width/2 
        self.floatY = self.homeY - self.height/2
        self.attackIndex = 0
        self.speed = Enemy.speedValue 
        self.angle = 0
        self.angleFound = False

    @classmethod   
    def flutterCheck(self,galaga):
        if self.flutterImage == True:
            self.flutterCount += 1
            if self.flutterCount == int(galaga.fps):
                self.flutterCount = 0
                self.flutterImage = False
        else:
            self.flutterCount += 1
            #Next Line: "Flutter" Twice per second.
            if self.flutterCount == int(galaga.fps)/2:  
                self.flutterImage = True

    def move(self):
        self.floatX += self.floatVX
        self.floatY += self.floatVY
        super(Enemy,self).move()

    def flutter(self):
        if self.flutterImage == True:
            self.image = self.openImage
            self.width = self.openImageWidth
            self.height = self.openImageHeight
        else:
            self.image = self.closedImage
            self.width = self.closedImageWidth
            self.height = self.closedImageHeight

    @classmethod
    def floatCheck(self,galaga):
        if self.floatOn == True:
            self.floatCount += 1
            if self.floatCount == int(galaga.fps*2):
                self.floatCount = 0
                self.floatOn = False
        else:
            self.floatOn = True

    def floatOut(self):
        if Enemy.floatOn == False:
            (self.floatVX,self.floatVY) = (-self.floatVX,-self.floatVY)
            
    def importSprites(self,closedImagePath,openImagePath):
        (self.closedImage,self.closedImageHeight,self.closedImageWidth) = \
              importImage(closedImagePath,True) #True == Alpha
        (self.openImage,self.openImageHeight,self.openImageWidth) = \
              importImage(openImagePath,True) #True == Alpha
        self.width = max(self.closedImageWidth,self.openImageWidth)
        self.height = max(self.closedImageHeight,self.openImageHeight)

    def setInitialLocation(self):
        self.x = self.homeX - self.width/2 
        self.y = self.homeY - self.height/2
        self.vx = 0
        self.vy = 0
        self.image = self.openImage

    def attack(self,galaga):
        self.attackPath = Movement.calculateAttackPath(self,galaga)
        self.isFlying = True
        self.isAttacking = True
        self.attackIndex = 1

    def update(self,galaga):
        self.flutter()
        self.floatOut()
        self.center = (self.x + self.width/2, self.y + self.height/2)
        if self.isFlying == False:
            self.x = self.floatX
            self.y = self.floatY
            self.vx = self.floatVX
            self.vy = self.floatVY
        else: #Enemy is flying.
            #Mid-Attack
            speed = self.speed

            startPoint = self.center
            targetPoint = self.attackPath[self.attackIndex]
            
            comp = galaga.PPT * speed #Pixels Per Tick
            
            if self.collisionWith(targetPoint,True): #True == collide with point
                self.attackIndex += 1
                self.angleFound = False
                if self.attackIndex==len(self.attackPath):#Completed the attack
                    self.reposition()    
                else:
                    startPoint = self.attackPath[self.attackIndex-1]
                    targetPoint = self.attackPath[self.attackIndex]

            (self.vx,self.vy) = Movement.calculateVelocity(startPoint,
                                          targetPoint,galaga.PPT,speed)

            self.angle = Movement.calculateAngle(self.vx,self.vy)
                
            self.rotateSprite(self.angle)

    def reposition(self):
        #Reposition to home
        self.x = self.floatX
        self.y = self.floatY
        self.vx = self.floatVX
        self.vy = self.floatVY
        self.isFlying = False
        self.isAttacking = False
        self.angle = 0
    
    def fireMissile(self,galaga):
        startPoint = (self.x,self.y)
        endPoint = (galaga.fighter.x,galaga.fighter.y)

        (vx,vy) = Movement.calculateVelocity(startPoint,endPoint)

        shooter = "enemy"

        return Missile(self.x+self.width/2,self.y+self.height/2,vx,vy,shooter)
        
        
        
###########
        
class EnemyGalaga(Enemy):
    def __init__(self,homeX,homeY):
        self.hitPoints = 2
        self.homeX = homeX
        self.homeY = homeY
        self.sprites()
        self.setInitialLocation()
        explosionPath = "enemy/explosion"
        self.expImages = PhysObj.getExplosions(explosionPath)
        self.deathSound = \
        pygame.mixer.Sound("galaga_sounds/enemy/galaga/galaga_stricken2.wav")
        self.weakSound =\
        pygame.mixer.Sound("galaga_sounds/enemy/galaga/galaga_stricken1.wav")
        self.points = 400
        self.multiplier = 1
        super(EnemyGalaga,self).__init__(self.x,self.y,self.vx,self.vy)

    def sprites(self):
        strongClosedImagePath = \
        "galaga_sprites/enemies/galaga/galaga_strong/galaga_strong_closed.png"
        strongOpenImagePath = \
        "galaga_sprites/enemies/galaga/galaga_strong/galaga_strong_open.png"
        weakClosedImagePath = \
        "galaga_sprites/enemies/galaga/galaga_weak/galaga_weak_closed.png"
        weakOpenImagePath = \
        "galaga_sprites/enemies/galaga/galaga_weak/galaga_weak_open.png"
        self.importSprites(strongClosedImagePath,strongOpenImagePath,
                           weakClosedImagePath,weakOpenImagePath)

    def importSprites(self,strongClosed,strongOpen,weakClosed,weakOpen):
        
        (self.strongClosedImage,self.strongClosedHeight,self.strongClosedWidth)\
              = importImage(strongClosed,True) #True == Alpha
        (self.strongOpenImage,self.strongOpenHeight,self.strongOpenWidth)\
              = importImage(strongOpen,True)
        
        (self.weakClosedImage,self.weakClosedHeight,self.weakClosedWidth)\
              = importImage(weakClosed,True)
        (self.weakOpenImage,self.weakOpenHeight,self.weakOpenWidth)\
              = importImage(weakOpen,True)
        
        self.openImage = self.strongOpenImage
        self.openImageWidth = self.strongOpenWidth
        self.openImageHeight = self.strongOpenHeight
        self.closedImage = self.strongClosedImage
        self.closedImageWidth = self.strongClosedWidth
        self.closedImageHeight = self.strongClosedHeight

        self.width = max(self.openImageWidth,self.closedImageWidth)
        self.height = max(self.openImageHeight,self.closedImageHeight)
        
###########
        
class EnemyButterfly(Enemy):
    def __init__(self,homeX,homeY):
        self.hitPoints = 1
        self.homeX = homeX
        self.homeY = homeY
        self.importSprites()
        self.setInitialLocation()
        explosionPath = "enemy/explosion"
        self.expImages = PhysObj.getExplosions(explosionPath)
        
        self.deathSound =\
    pygame.mixer.Sound("galaga_sounds/enemy/butterfly/butterfly_stricken.wav")
        self.points = 80
        self.multiplier = 1
        super(EnemyButterfly,self).__init__(self.x,self.y,self.vx,self.vy)

    def importSprites(self):
        closedImagePath = \
        "galaga_sprites/enemies/butterfly/butterfly_closed.png"
        openImagePath = \
        "galaga_sprites/enemies/butterfly/butterfly_open.png"
        super(EnemyButterfly,self).importSprites(closedImagePath,openImagePath)

###########
        
class EnemyBee(Enemy):
    def __init__(self,homeX,homeY):
        self.hitPoints = 1
        self.homeX = homeX
        self.homeY = homeY
        self.importSprites()
        self.setInitialLocation()
        explosionPath = "enemy/explosion"
        self.expImages = PhysObj.getExplosions(explosionPath)
        self.deathSound = \
        pygame.mixer.Sound("galaga_sounds/enemy/bee/bee_stricken.wav")
        self.points = 40
        self.multiplier = 1
        super(EnemyBee,self).__init__(self.x,self.y,self.vx,self.vy)

    def importSprites(self):
        closedImagePath = \
        "galaga_sprites/enemies/bee/bee_closed.png"
        openImagePath = \
        "galaga_sprites/enemies/bee/bee_open.png"
        super(EnemyBee,self).importSprites(closedImagePath,openImagePath)
        
#############
#Explosions!#
#############
        
class Explosion(PhysObj):
    def __init__(self,character,galaga):
        explosionSpeed = 3
        # Next Line: Stores a 3-tuple list of images[0], image width[1],
        # and image height[2].
        self.expImages = character.expImages 
        self.expFrames = len(character.expImages)
        self.expFrameRate = int(round(galaga.fps/explosionSpeed/self.expFrames))
        self.fps = int(galaga.fps)/explosionSpeed
        self.frameIndex = 0
        self.frame = 0
        self.isAlive = True
        self.characterX = character.x
        self.characterY = character.y
        self.characterWidth = character.width
        self.characterHeight = character.height

    def update(self):
        if self.frame >= self.fps:
            self.isAlive = False
        if self.frame != 0 and self.frame % self.expFrameRate == 0:
            self.frameIndex += 1   
        self.frame += 1

    def draw(self,galaga):
        self.image = self.expImages[self.frameIndex][0]
        self.imageWidth = self.expImages[self.frameIndex][1]
        self.imageHeight = self.expImages[self.frameIndex][2]
        self.x = self.characterX + self.characterWidth/2 - self.imageWidth/2
        self.y = self.characterY + self.characterHeight/2 - self.imageHeight/2
        super(Explosion,self).draw(galaga)
        
#############
#Formations!#
#############
        
class Formations(object):
    def __init__(self,formation,galaga):
        self.formation = formation
        self.defineEnemies()
        self.makeFormation(galaga)

    def defineEnemies(self):
        if self.formation == 1:
            self.totalEnemies = 36
            self.bossGalaga = 4
            self.butterflies = 16
            self.bees = 16
            self.enemiesPerRow = 8
            self.rows = math.ceil((self.totalEnemies*1.0)/self.enemiesPerRow)
        
    def makeFormation(self,galaga):
        positionList = []
        #Next Line: 21 Pixels is the base size of an enemy location
        self.offset = offset = 21 * Galaga.screenScale
        if self.formation == 1:
            #Central Points of Formation, used to apply "floating" animation
            #effect. 
            self.formationX = galaga.screenWidth/2
            self.formationY = self.offset + galaga.header
            totalEnemies = self.totalEnemies
            bossGalaga = self.bossGalaga
            enemiesPerRow = self.enemiesPerRow
            for position in xrange(totalEnemies):
                if (position <= (bossGalaga-1)): #Top 4 Boss Galagas
                    row = 0
                    rowPosition = position
                    posX = ((galaga.screenWidth/2 - offset*(bossGalaga/2))\
                            +offset/2+offset*rowPosition)
                    posY = (offset + offset*row + galaga.header) #1 empty space above enemies
                    positionList.append([posX,posY])
                else: #Basic enemy
                    row = (position-bossGalaga)/enemiesPerRow + 1
                    rowPosition = position % enemiesPerRow
                    #Leftmost Position In Row + Actual Row Position
                    posX = ((galaga.screenWidth/2 - offset*(enemiesPerRow/2))\
                            +offset/2+offset*rowPosition)
                    
                    posY = (offset + (offset*.75)*row + galaga.header)
                    positionList.append([posX,posY])
        self.positionList = positionList

###########
#Movement!#
###########

class Movement(object):
    @classmethod
    def calculateFloat(self,character,galaga):
        (xFloat,yFloat) = self.floatDistance(character,galaga)
        
        #Distance traveled per tick
        xTick = xFloat / (galaga.fps)
        yTick = yFloat / (galaga.fps)

        return (xTick,yTick)
    
    @classmethod    
    def floatDistance(self,character,galaga):
        #Calculate furthest possible x and y position from formation center
        wideOffset=abs(galaga.formation.offset * galaga.formation.enemiesPerRow)
        heightOffset=(galaga.formation.offset * galaga.formation.rows)

        #Calculate Character's distance from formation center
        xDistance = -(galaga.formation.formationX - character.homeX)
        yDistance = -(galaga.formation.formationY - character.homeY)

        #Calculate Ratio of distance from formation center
        xRatio = xDistance/(wideOffset*1.0)
        yRatio = yDistance/(heightOffset*1.0)

        #Total Distance character should travel while floating
        xFloat = galaga.formation.offset * xRatio
        yFloat = galaga.formation.offset * yRatio

        return (xFloat,yFloat)

    @classmethod
    def calculateAttackPath(self,character,galaga):
        pointList = []
        
        fighterX = galaga.fighter.x
        fighterY = galaga.fighter.y
        
        xChange = (fighterX - character.x)/2
        yChange = (fighterY - character.y)/2

        characterAdjust = character.width/2 #Square Images
        fighterAdjust = galaga.fighter.width/2

        #These Points Are hardcoded for testing purposes

        enemyPoint = (character.x + characterAdjust,character.y + characterAdjust)
        midPoint = (character.x + xChange, character.y + yChange)
        fighterPoint = (fighterX+fighterAdjust,fighterY+fighterAdjust)
        endPoint = (fighterX+fighterAdjust,fighterY+fighterAdjust + characterAdjust)

        pointList.append(enemyPoint)
        pointList.append(midPoint)

        angleIncrement = 5
        pointIndex = 1
        angleIndex = 1
        circumference = 200 * Galaga.screenScale
        steps = int(360 / angleIncrement) #360 degrees in a circle
        stepLength = int(circumference / steps) #hypotenuse
        for step in xrange(steps-1):
            angle = math.radians(angleIncrement * angleIndex)
            xDifference = math.sin(angle) * stepLength
            yDifference = (math.cos(angle) * stepLength)
            if character.x-fighterX < 0:
                yDifference = yDifference
                xDifference = -xDifference
            lastPointX = pointList[pointIndex][0]
            lastPointY = pointList[pointIndex][1]
            newX = lastPointX + xDifference
            newY = lastPointY + yDifference
            pointList.append((newX,newY))
            angleIndex += 1
            pointIndex += 1
        pointList.append(fighterPoint)
        pointList.append(endPoint)
        return pointList

    @classmethod
    def calculateVelocity(self, startPoint,targetPoint,PPT,speed):
        (startX,startY) = (startPoint[0],startPoint[1])
        (targetX,targetY) = (targetPoint[0],targetPoint[1])
        
        distance = ((targetX - startX)**2 + (targetY - startY)**2)**0.5

        divisionVariable = distance / PPT #Pixels Per Tick
    
        vector = ((targetPoint[0] - startPoint[0]),
          (targetPoint[1] - startPoint[1]))

        xVelocity =  (vector[0] / divisionVariable) * speed 
        yVelocity =  (vector[1] / divisionVariable) * speed
        
        return (xVelocity,yVelocity)

    @classmethod
    def calculateAngle(self,vx,vy):
        if (vx < 0 and vy == 0):
            angle = 90
        elif (vx > 0 and vy ==0):
            angle = -90
        else:
            if vy > 0:    
                angle = math.degrees(math.atan(vx/vy)) + 180
            else:
                angle = math.degrees(math.atan(vx/vy))
        return angle
               
Galaga()



        
