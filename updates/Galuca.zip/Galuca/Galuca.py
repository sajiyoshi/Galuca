import sys,pygame
from pygame.locals import *
pygame.init()

import random

class Galaga(object):
    screenScale = 3
    def __init__(self):
        self.baseWidth = 224
        self.baseHeight = 288
        self.screenWidth = int(self.baseWidth * self.screenScale)
        self.screenHeight = int(self.baseHeight * self.screenScale)
        self.runGalaga()
        
    def runGalaga(self):
        self.init()
        while True:
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == KEYDOWN or event.type == KEYUP:
                    self.keyPressed(event)
            self.keepTime()
            self.moveGalaga()
            self.drawGalaga()
            pygame.time.delay(int(1000/self.fps)) #1000 milliseconds/fps

    def keepTime(self):
        self.milliseconds += self.clock.tick()
        self.seconds = self.milliseconds/1000.0
        
    def init(self):
        self.gameTitle = "Galuca"
        self.fps = 60.0
        self.initScreen()
        self.initFighter()
        self.initObjects()
        
    def keyPressed(self,event):
        if event.type == KEYDOWN:
            if event.key == K_LEFT:
                self.fighter.vx = -self.fighter.speed
            elif event.key == K_RIGHT:
                self.fighter.vx = self.fighter.speed
            elif event.key == K_SPACE:
                if len(self.missileList) < Missile.maxMissiles:
                    self.shotsFired += 1
                    self.missileList.append(self.fighter.fireMissile(self.\
                                                        fighterMissileSpeed))
            elif event.key == K_a:
                self.enemyList.append(EnemyGalaga())
        elif event.type == KEYUP:
            if event.key == K_LEFT:
                if self.fighter.vx < 0:
                    self.fighter.vx = 0
            elif event.key == K_RIGHT:
                if self.fighter.vx >0:
                    self.fighter.vx = 0
        
    def initFighter(self):
        self.fighterMissileSpeed = -int(self.screenHeight/self.fps*1.5)
        self.fighter = Fighter(self)
        
    def initObjects(self):
        self.missileList = []
        
        self.starList = []
        baseStarSize = 1
        self.starSizes = [baseStarSize,baseStarSize*2,baseStarSize*3-1]
        baseStarSpeed = self.screenHeight/200
        self.starSpeeds = [-baseStarSpeed,-int(baseStarSpeed*1.3),
                           -int(baseStarSpeed*1.6)]

        a = EnemyGalaga()
        b = EnemyGalaga()
        c = EnemyGalaga()
        d = EnemyButterfly()
        e = EnemyBee()
        self.enemyList = [a,b,c,d,e]

        self.formation = FormationGenerator.makeFormation(1,self)
        print self.formation
        
        self.explosionList = []
        
        self.score = 0

        self.shotsFired = 0
        self.shotsHit = 0
        
        self.clock = pygame.time.Clock() #Initialize game clock
        self.milliseconds = 0
        
    def initScreen(self):
        self.screenSize = self.screenWidth,self.screenHeight
        self.screen = pygame.display.set_mode(self.screenSize)
        pygame.display.set_caption(self.gameTitle)
        
    def drawGalaga(self):
        self.drawScreen()
        pygame.display.update()

    def drawScreen(self):
        self.screen.fill((0,0,0))
        self.drawStars()
        self.drawFighter()
        self.drawEnemies()
        self.drawMissiles()
        self.drawFormation()
        self.drawExplosions()

    def drawFormation(self):
        for location in self.formation:
            pygame.draw.circle(self.screen,(255,255,255),(location[0],location[1]),
                                                             10)
            
    def drawEnemies(self):
        for enemy in self.enemyList:
            enemy.draw(self)

    def drawMissiles(self):
        for missile in self.missileList:
            missile.draw(self)

    def drawStars(self):
        starLife = self.fps/2
        starWait = self.fps/10
        for star in self.starList:
            if star.flash == starLife: #Reset Star Flash
                star.flash = 0
            elif star.flash > starWait: #Only draw if flash is on.  
                star.draw(self) #Draw method
                star.flash += 1
            else:
                star.flash += 1
            
    def drawFighter(self):
        self.fighter.draw(self)

    def drawExplosions(self):
        for explosion in self.explosionList:
            explosion.draw(self)

    def moveGalaga(self):
        self.moveFighter()
        self.moveStars()
        self.moveMissiles()
        self.moveEnemies()
        self.updateExplosions()
        self.checkForCollisions()

    def moveEnemies(self):
        Enemy.flutterCheck(self)
        
        for enemy in self.enemyList:
            enemy.flutter()
        self.enemyList = [enemy for enemy in self.enemyList \
                            if (enemy.isAlive)]

    def moveFighter(self):
        """Checks to ensure fighter is within the bounds of the board, and then
            moves the fighter in the proper direction."""
        if self.fighter.vx < 0:
            if self.fighter.x >= 0:
                self.fighter.x += self.fighter.vx
        elif self.fighter.vx > 0:
            if self.fighter.x <= self.screenWidth - self.fighter.width:
                self.fighter.x += self.fighter.vx

    def moveStars(self):
        numberOfStars = self.screenHeight/20
        startingStars = numberOfStars-1
        if len(self.starList) < startingStars:
               self.starList.append(Star.createStar(self,True))#Random star
        elif len(self.starList) < numberOfStars:
            self.starList.append(Star.createStar(self,False))#Non random star
        for star in self.starList:
            star.move()
        self.starList =[star for star in self.starList if star.isOnScreen(self)]

    def moveMissiles(self):
        for missile in self.missileList:
            missile.move()
        #Next Lines: Removes all missiles which have traveled off screen.
        self.missileList = [missile for missile in self.missileList \
                            if (missile.isOnScreen(self) and missile.isAlive)]
    def updateExplosions(self):
        for explosion in self.explosionList:
            explosion.update()
        self.explosionList = [explosion for explosion in self.explosionList \
                              if (explosion.isAlive)]

    def checkForCollisions(self):
        for missile in self.missileList:
            for enemy in self.enemyList:
                if (enemy.collisionWith(missile) and (missile.isAlive)):
                    self.shotsHit += 1
                    missile.isAlive = False
                    enemy.hitPoints -= 1  
                    if enemy.hitPoints == 0:
                        enemy.deathSound.play()
                        enemy.isAlive = False
                        self.explosionList.append(Explosion(enemy,self))
                    elif isinstance(enemy,EnemyGalaga):
                        enemy.weakSound.play()
                        enemy.openImage = enemy.weakOpenImage
                        enemy.closedImage = enemy.weakClosedImage

##################
#Utility Function#
##################
                    
def importImage(filePath,alpha,screenScale=Galaga.screenScale):
        """Imports an image and rescales it by the proper offset."""
        image = pygame.image.load(filePath)
        
        if alpha == True:
            image = image.convert_alpha()
        else:
            image = image.convert()
        imageHeight = int(image.get_height() * screenScale)
        imageWidth = int(image.get_width() * screenScale)
        
        return (pygame.transform.scale(image,(imageWidth,imageHeight)),
                                             imageHeight,imageWidth)

################################
#       Physics Objects        #
#Anything that moves on screen!#
################################

class PhysObj(object):
    def __init__(self,x,y,vx,vy):
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.isAlive = True

    def move(self):
        """Repositions a physics object by it's x and y velocity."""
        self.x += self.vx
        self.y += self.vy

    def isOnScreen(self,galaga):
        """Returns True if object is on screen and False otherwise."""
        if self.x < 0 or self.x > galaga.screenWidth or\
           self.y < 0 or self.y > galaga.screenHeight:
            return False
        else:
            return True

    def draw(self,galaga):
        galaga.screen.blit(self.image,(self.x,self.y))

    def importSprite(self,imageFilePath,alpha):
        (self.image,self.height,self.width) = \
              importImage(imageFilePath,True) #True == Alpha

    #Rotation function taken from: http://www.pygame.org/wiki/RotateCenter
    def rotateSprite(self,angle):
        """rotate an image while keeping its center and size"""
        orig_rect = self.image.get_rect()
        rot_image = pygame.transform.rotate(self.image, angle)
        rot_rect = orig_rect.copy()
        rot_rect.center = rot_image.get_rect().center
        rot_image = rot_image.subsurface(rot_rect).copy()
        self.image = rot_image #My Modification 
        
    def collisionWith(self,other):
        hitBoxX0 = self.x-other.width
        hitBoxY0 = self.y
        hitBoxX1 = self.x+self.width+other.width
        hitBoxY1 = self.y+self.height
        if (other.x >= hitBoxX0 and other.x <= hitBoxX1) and \
           (other.y >= hitBoxY0 and other.y <= hitBoxY1):
            return True
        return False

    @classmethod
    def getExplosions(self,classPath):
        imageList = []
        index = 1
        pathFound = True
        while pathFound:
            pathName = "galaga_sprites/explosions/%s_%d.png" % (classPath,index)
            try:
               imageList.append(importImage(pathName,True,Galaga.screenScale+1))
               index += 1
            except:
               pathFound = False
               return imageList
                
               
class Missile(PhysObj):
    maxMissiles = 4 #Classic Galaga only allowed 4 missiles on screen. 
    def __init__(self,x,y,vx,vy,shooter):
        self.shooter = shooter
        self.importSprite()
        super(Missile,self).__init__(x-self.width/2,y-self.height,vx,vy)

    def importSprite(self):
        if self.shooter == "fighter":
            imageFilePath = "galaga_sprites/missiles/fighter_missile.png"
        elif self.shooter == "enemy":
            imageFilePath = "galaga_sprites/missiles/enemy_missile.png"
        super(Missile,self).importSprite(imageFilePath,True)

class Fighter(PhysObj):
    def __init__(self,galaga):
        self.importSprite()
        self.setInitialLocation(galaga)
        self.speed = int(galaga.screenWidth/galaga.fps)
        super(Fighter,self).__init__(self.x,self.y,self.vx,self.vy)

    def importSprite(self):
        imageFilePath = "galaga_sprites/fighter/fighter.png"
        super(Fighter,self).importSprite(imageFilePath,True)
        
    def setInitialLocation(self,galaga):
        self.x = galaga.screenWidth/2 - self.width/2
        self.y = galaga.screenHeight - self.height
        #Next Lines: Inital Speed of fighter is 0. 
        self.vx = 0
        self.vy = 0

    def fireMissile(self,missileSpeed):
        #Set base parameters
        vx = 0
        vy = missileSpeed 
        shooter = "fighter"

        #Play missile Sound
        sound = pygame.mixer.Sound('galaga_sounds/fighter/fighter_shot1.wav')
        sound.play()

        #Return Missile Instance
        return Missile(self.x+self.width/2,self.y,vx,vy,shooter)

class Star(PhysObj):
    def __init__(self,x,y,vx,vy,size,flash):
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.size = size
        self.flash = flash

    @classmethod
    def createStar(self,galaga,randomStar):
        """Choose random variables to create a circle which simulates stars
            with a paralax effect."""
        x = random.randint(0,galaga.screenWidth)
        if randomStar == False:
            y = 0
        else:
            y = random.randint(0,galaga.screenHeight)
        vx = 0
        vy = -random.choice(galaga.starSpeeds) 
        size = random.choice(galaga.starSizes) 
        flash = random.randint(0,galaga.fps/2)
        return Star(x,y,vx,vy,size,flash)

    def draw(self,galaga):
        pygame.draw.circle(galaga.screen,(255,255,255),(self.x,self.y),
                                                             self.size)

class Enemy(PhysObj):
    flutterImage = True
    flutterCount = 0
    def __init__(self,x,y,vx,vy):
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.path = []
        self.isAlive = True

    @classmethod   
    def flutterCheck(self,galaga):
        if self.flutterImage == True:
            self.flutterCount += 1
            if self.flutterCount == int(galaga.fps):
                self.flutterCount = 0
                self.flutterImage = False
        else:
            self.flutterCount += 1
            #Next Line: "Flutter" Twice per second.
            if self.flutterCount == int(galaga.fps)/2:  
                self.flutterImage = True

    def flutter(self):
        if self.flutterImage == True:
            self.image = self.openImage
            self.width = self.openImageWidth
            self.height = self.openImageHeight
        else:
            self.image = self.closedImage
            self.width = self.closedImageWidth
            self.height = self.closedImageHeight
          
    def importSprites(self,closedImagePath,openImagePath):
        (self.closedImage,self.closedImageHeight,self.closedImageWidth) = \
              importImage(closedImagePath,True) #True == Alpha
        (self.openImage,self.openImageHeight,self.openImageWidth) = \
              importImage(openImagePath,True) #True == Alpha

class EnemyGalaga(Enemy):
    def __init__(self):
        self.hitPoints = 2
        self.sprites()
        self.setInitialLocation()
        explosionPath = "enemy/explosion"
        self.expImages = PhysObj.getExplosions(explosionPath)
        self.deathSound = \
        pygame.mixer.Sound("galaga_sounds/enemy/galaga/galaga_stricken2.wav")
        self.weakSound =\
        pygame.mixer.Sound("galaga_sounds/enemy/galaga/galaga_stricken1.wav")
        super(EnemyGalaga,self).__init__(self.x,self.y,self.vx,self.vy)

    def sprites(self):
        strongClosedImagePath = \
        "galaga_sprites/enemies/galaga/galaga_strong/galaga_strong_closed.png"
        strongOpenImagePath = \
        "galaga_sprites/enemies/galaga/galaga_strong/galaga_strong_open.png"
        weakClosedImagePath = \
        "galaga_sprites/enemies/galaga/galaga_weak/galaga_weak_closed.png"
        weakOpenImagePath = \
        "galaga_sprites/enemies/galaga/galaga_weak/galaga_weak_open.png"
        self.importSprites(strongClosedImagePath,strongOpenImagePath,
                           weakClosedImagePath,weakOpenImagePath)

    def importSprites(self,strongClosed,strongOpen,weakClosed,weakOpen):
        
        (self.strongClosedImage,self.strongClosedHeight,self.strongClosedWidth)\
              = importImage(strongClosed,True) #True == Alpha
        (self.strongOpenImage,self.strongOpenHeight,self.strongOpenWidth)\
              = importImage(strongOpen,True)
        
        (self.weakClosedImage,self.weakClosedHeight,self.weakClosedWidth)\
              = importImage(weakClosed,True)
        (self.weakOpenImage,self.weakOpenHeight,self.weakOpenWidth)\
              = importImage(weakOpen,True)
        
        self.openImage = self.strongOpenImage
        self.openImageWidth = self.strongOpenWidth
        self.openImageHeight = self.strongOpenHeight
        self.closedImage = self.strongClosedImage
        self.closedImageWidth = self.strongClosedWidth
        self.closedImageHeight = self.strongClosedHeight
        
    def setInitialLocation(self):
        self.x = random.randint(0,450) #Random Location for testing purposes. 
        self.y = random.randint(0,200)
        self.vx = 0
        self.vy = 0
        self.image = self.openImage

class EnemyButterfly(Enemy):
    def __init__(self):
        self.hitPoints = 1
        self.importSprites()
        self.setInitialLocation()
        explosionPath = "enemy/explosion"
        self.expImages = PhysObj.getExplosions(explosionPath)
        
        self.deathSound =\
    pygame.mixer.Sound("galaga_sounds/enemy/butterfly/butterfly_stricken.wav")
        super(EnemyButterfly,self).__init__(self.x,self.y,self.vx,self.vy)

    def importSprites(self):
        closedImagePath = \
        "galaga_sprites/enemies/butterfly/butterfly_closed.png"
        openImagePath = \
        "galaga_sprites/enemies/butterfly/butterfly_open.png"
        super(EnemyButterfly,self).importSprites(closedImagePath,openImagePath)

    def setInitialLocation(self):
        self.x = random.randint(0,450) #Random Location for testing purposes. 
        self.y = 50
        self.vx = 0
        self.vy = 0
        self.image = self.openImage

class EnemyBee(Enemy):
    def __init__(self):
        self.hitPoints = 1
        self.importSprites()
        self.setInitialLocation()
        explosionPath = "enemy/explosion"
        self.expImages = PhysObj.getExplosions(explosionPath)
        self.deathSound = \
        pygame.mixer.Sound("galaga_sounds/enemy/bee/bee_stricken.wav")
        super(EnemyBee,self).__init__(self.x,self.y,self.vx,self.vy)

    def importSprites(self):
        closedImagePath = \
        "galaga_sprites/enemies/bee/bee_closed.png"
        openImagePath = \
        "galaga_sprites/enemies/bee/bee_open.png"
        super(EnemyBee,self).importSprites(closedImagePath,openImagePath)

    def setInitialLocation(self):
        self.x = random.randint(0,450) #Random Location for testing purposes. 
        self.y = 50
        self.vx = 0
        self.vy = 0
        self.image = self.openImage    
        
class Explosion(PhysObj):
    def __init__(self,character,galaga):
        explosionSpeed = 3
        # Next Line: Stores a 3-tuple list of images[0], image width[1],
        # and image height[2].
        self.expImages = character.expImages 
        self.expFrames = len(character.expImages)
        self.expFrameRate = int(round(galaga.fps/explosionSpeed/self.expFrames))
        self.fps = int(galaga.fps)/explosionSpeed
        self.frameIndex = 0
        self.frame = 0
        self.isAlive = True
        self.characterX = character.x
        self.characterY = character.y
        self.characterWidth = character.width
        self.characterHeight = character.height

    def update(self):
        if self.frame >= self.fps:
            self.isAlive = False
        if self.frame != 0 and self.frame % self.expFrameRate == 0:
            self.frameIndex += 1   
        self.frame += 1

    def draw(self,galaga):
        self.image = self.expImages[self.frameIndex][0]
        self.imageWidth = self.expImages[self.frameIndex][1]
        self.imageHeight = self.expImages[self.frameIndex][2]
        self.x = self.characterX + self.characterWidth/2 - self.imageWidth/2
        self.y = self.characterY + self.characterHeight/2 - self.imageHeight/2
        super(Explosion,self).draw(galaga)

class FormationGenerator(object):
    def __init__(self, galaga):
        self.makeFormation(galaga)
        
    @classmethod
    def makeFormation(self,formation,galaga):
        self.formation = formation
        positionList = []
        offset = 21 * Galaga.screenScale #21px is the base amount of enemy space 
        if self.formation == 1:
            self.totalEnemies = totalEnemies = 28
            self.bossGalaga = bossGalaga = 4
            self.butterflies = 8
            self.bees = 16
            self.enemiesPerRow = enemiesPerRow = 8
            for position in xrange(totalEnemies):
                if (position <= (bossGalaga-1)): #Top 4 Boss Galagas
                    row = 1
                    rowPosition = position
                    posX = ((galaga.screenWidth/2 - offset*(bossGalaga/2))\
                            +offset*rowPosition)
                    posY = (offset + offset*row) #1 empty space above enemies
                    positionList.append([posX,posY,True])
                else: #Basic enemy
                    row = (position-bossGalaga)/enemiesPerRow + 1
                    rowPosition = position % enemiesPerRow
                    posX = ((galaga.screenWidth/2 - offset*(enemiesPerRow/2))\
                            +offset*rowPosition)
                    posY = (offset + offset*row)
                    positionList.append([posX,posY,True])
        return positionList
                    
                    
                
Galaga()


        
